package app;
//
public class initDepositAmountException extends Exception{
	public initDepositAmountException() {	}
	public initDepositAmountException(String msg) {
		super(msg);
	}
	
}
